 package BaseClass;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;

import Util.ReadExcel;
import org.testng.annotations.Parameters;


public class TestBase  {
	public static ChromeDriver driver;
	public String filename;
	public static Properties prop;
	
	@Parameters({ "url" ,"propFile"})
	@BeforeMethod
	public void preCondition(@Optional String url, @Optional String login) throws IOException {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		FileInputStream fis = new FileInputStream("src/main/resources/"+login+".properties");
		prop = new Properties();
		prop.load(fis);	
	}
		
	@AfterMethod
	   public void postCondition() {
		driver.close();
		}
	
		@DataProvider(indices = 1)
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(filename);
		return data;
	}
	
}
