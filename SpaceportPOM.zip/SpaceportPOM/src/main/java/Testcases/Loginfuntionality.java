package Testcases;
import org.testng.annotations.Test;
import BaseClass.TestBase;
import Pages.LoginPage;

public class Loginfuntionality extends TestBase{

	@Test
	public static void runLogin() throws Exception {
		
		LoginPage lp=new LoginPage (driver);	//1234
		Thread.sleep(3000);
		lp.signin();
		lp.Enterusername();
		lp.Enterphonenumber();
		lp.Enteryear();
		lp.clickEngage();
			
	}
	
}
