package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

import BaseClass.TestBase;


public class LoginPage  extends TestBase{
	
	public LoginPage (ChromeDriver driver) {
		this.driver = driver;
	}	
	
	public LoginPage signin() {
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div/div[3]/a")).click();
		return this;
		}
	
	public LoginPage Enterusername() {
		driver.findElement(By.xpath("//input[@id='formBasicEmail']")).sendKeys(prop.getProperty("username"));
		return this;
		}
	
	public LoginPage Enterphonenumber() {
		driver.findElement(By.xpath("//input[@class='form-control text-white']")).sendKeys(Keys.BACK_SPACE);
		driver.findElement(By.xpath("//input[@class='form-control text-white']")).sendKeys(prop.getProperty("phonenumber"));
		return this;
			}
	
	public LoginPage Enteryear() {
		driver.findElement(By.xpath("//input[@placeholder='Year of Birth']")).sendKeys(prop.getProperty("year"));
		return this;
				}
	public OtpPage clickEngage() {
		driver.findElement(By.xpath("//button[contains(@class,'login_appButton__cvlVK btn')]")).click();
		return new OtpPage();
	}

	
}
