package Pages;
import org.openqa.selenium.By;
import BaseClass.TestBase;

public class OtpPage extends TestBase {
	
		public OtpPage enterotp(int otp) {
		driver.findElement(By.xpath("//div[@class='container']")).click();
		driver.findElement(By.xpath("(//input[@class='inputStyle'])[1]")).sendKeys(prop.getProperty("otp1"));
		driver.findElement(By.xpath("(//input[@class='inputStyle'])[2]")).sendKeys(prop.getProperty("otp2"));
		driver.findElement(By.xpath("(//input[@class='inputStyle'])[3]")).sendKeys(prop.getProperty("otp3"));
		driver.findElement(By.xpath("(//input[@class='inputStyle'])[4]")).sendKeys(prop.getProperty("otp4"));
		driver.findElement(By.xpath("(//input[@class='inputStyle'])[5]")).sendKeys(prop.getProperty("otp5"));
		driver.findElement(By.xpath("(//input[@class='inputStyle'])[6]")).sendKeys(prop.getProperty("otp6"));
		return this;
		}
		
		
		public HomePage clickLogin() {
			driver.findElement(By.xpath("//button[@class='appButton my-32 btn btn-primary']")).click();
			String title = driver.getTitle();
			System.out.println(title);
			return new HomePage();
			
		}
	
	
}
