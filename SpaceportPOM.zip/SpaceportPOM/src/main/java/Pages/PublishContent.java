package Pages;

import BaseClass.TestBase;

public class PublishContent  extends TestBase {

}
