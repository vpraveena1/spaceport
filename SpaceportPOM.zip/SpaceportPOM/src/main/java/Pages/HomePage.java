package Pages;
import org.openqa.selenium.By;
import BaseClass.TestBase;

public class HomePage  extends TestBase {

	public MyPortal  clickportal() {
		driver.findElement(By.xpath("//a[@href='/myportal']")).click();
		return new MyPortal();
			}
	
	public PublishContent  clickpublishcontent() {
		driver.findElement(By.xpath("//a[@href='/create-content']")).click();
		return new PublishContent();
			}
	public ProfileName clickprofilename() {
		driver.findElement(By.xpath("//span[@class='block text-sm font-medium']")).click();
		return new ProfileName();
	       }
	public ProfileSetting clicksetting() {
		driver.findElement(By.xpath("(//a[@href='/quickstats'])[1]")).click();
		return new ProfileSetting();
	       }
	
	}
	
