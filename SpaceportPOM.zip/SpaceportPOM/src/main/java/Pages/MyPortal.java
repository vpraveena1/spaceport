package Pages;
import org.openqa.selenium.By;
import BaseClass.TestBase;

public class MyPortal  extends TestBase {

	public MyPortal clickvideo() {
		driver.findElement(By.xpath("(//div[@class='slick-slide slick-active slick-current'])[2]")).click();
		driver.findElement(By.xpath("(//video[@width='500'])[5]")).click();
		return this;
		
	}
	
	
	
	
	
	
	
	
}
