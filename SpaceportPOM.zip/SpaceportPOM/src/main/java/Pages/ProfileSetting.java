package Pages;

import org.openqa.selenium.By;

import BaseClass.TestBase;

public class ProfileSetting  extends TestBase{
	
	public ProfileSetting clickQuickstatsPorter() throws InterruptedException {
		driver.findElement(By.xpath("(//a[@href='/quickstats'])[2]")).click();
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//div[text()='Spacer']")).click();
		 return this;
   }

	public ProfileSetting clickPayment() throws InterruptedException {
		driver.findElement(By.xpath("//a[@href='/payments']")).click();
		 Thread.sleep(3000);
		 return this;
	}
	
	public ProfileSetting clickPersonalInfo() throws InterruptedException {
		driver.findElement(By.xpath("//a[@href='/personalInfo']")).click();
		 Thread.sleep(3000);
		 return this;
	}
	
	public ProfileSetting clickSettings() throws InterruptedException {
		driver.findElement(By.xpath("//a[@href='/settings']")).click();
		 Thread.sleep(3000);
		 return this;
	}
	
	
	
	
	
	
}